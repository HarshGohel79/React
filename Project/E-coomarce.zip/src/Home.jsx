// import React from 'react'
// import Hedar from './componet/Hedar'
// import Navbarr from './componet/Navbarr'
// import Footer from './componet/Footer'
// import FeaturedStart from './componet/FeaturedStart'
// import Categories from './componet/Categories'
// import Offer from './componet/Offer'
// import Productsstart from './componet/Product.jsx'
// import SubscribeStart from './SubscribeStart.jsx'
// import Product from './componet/02Product.jsx'
// import VendorStart from './componet/VendorStart.jsx'
// import { BrowserRouter, Route, Routes } from 'react-router-dom'



// function Home() {
//   return (
//     <div>


// <Hedar/>
// <Navbarr/>
// <FeaturedStart/>
// <Categories/>
// <Offer/>
// <Productsstart/>
// <SubscribeStart/>
// <Product/>
// <VendorStart/>
// <Footer/>

  


  




   


    







  


//     </div>
//   )
// }

// export default Home
