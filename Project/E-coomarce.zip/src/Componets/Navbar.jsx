import React, { useContext } from 'react'
import { Link, useNavigate } from 'react-router-dom'

import { UserLogin } from '../App'

function Navbarr() {

 const {loginame} =  useContext(UserLogin)

 console.log(loginame)
  return (
    <div>
         <header className="p-3 bg-dark text-white">
      <div className="container">
        <div className="d-flex flex-wrap align-items-center justify-content-between">
          <a href="/" className="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
           <h1>KriShiv</h1>
          </a>
          <ul className="nav me-auto mb-2 justify-content-center mb-md-0">
          <li><a href="#" className="nav-link px-2 text-white"><Link to={'/'}>Home</Link></a></li>
            <li><a href="#" className="nav-link px-2 text-white"><Link to={'/Men'}>Men</Link></a></li>
            <li><a href="#" className="nav-link px-2 text-white"><Link to={'/Womens'}>Womens</Link></a></li>
            <li><a href="#" className="nav-link px-2 text-white"><Link to={'/kids'}>Kids</Link></a></li>
            <li><a href="#" className="nav-link px-2 text-white"><Link to={'/Beauty'}>Beauty</Link></a></li>
            
          </ul>

          <form className="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3">
            <input type="search" className="form-control form-control-dark" placeholder="Search..." aria-label="Search"/>

            <h1></h1>

          </form>

          <div className="text-end">
            <button type="button" className="btn btn-outline-light me-2"><Link to={'/login'}>Login</Link></button>
            <button type="button" className="btn btn-warning"><Link to={'/Sign'}>Sign-up</Link></button>
          </div>
        </div>
      </div>
    </header>
    </div>
  )
}

export default Navbarr