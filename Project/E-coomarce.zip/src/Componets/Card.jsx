import React from 'react'
import p1 from '../public/prod-Imges/p-1.jpeg'
import p2 from '../public/prod-Imges/p-2.jpeg'
import p3 from '../public/prod-Imges/p-3.jpeg'
import p4 from '../public/prod-Imges/p-4.jpeg'
import p5 from '../public/prod-Imges/p-5.jpeg'
import p6 from '../public/prod-Imges/p-6.webp'
import p7 from '../public/prod-Imges/p-7.jpeg'
import p8 from '../public/prod-Imges/p-8.jpeg'



function Card() {
  return (
    <div>
<div className="container py-5">
    <h2 className="mb-4">Shop by Category</h2>

    <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
      {/* <!-- Category Card --> */}
      <div className="col">
        <div className="card text-center h-100 border-0 shadow-sm">
          <div className="card-body">
            <img src={p1} className="mb-3" alt="Category Icon" />
            
          </div>
        </div>
      </div>

	  <div className="col">
        <div className="card text-center h-100 border-0 shadow-sm">
          <div className="card-body">
            <img src={p2} className="mb-3" alt="Category Icon" />
            
          </div>
        </div>
      </div>

	  <div className="col">
        <div className="card text-center h-100 border-0 shadow-sm">
          <div className="card-body">
            <img src={p3} className="mb-3" alt="Category Icon" />
            
          </div>
        </div>
      </div>

	  <div className="col">
        <div className="card text-center h-100 border-0 shadow-sm">
          <div className="card-body">
            <img src={p4} className="mb-3" alt="Category Icon" />
            
          </div>
        </div>
      </div>

	  <div className="col">
        <div className="card text-center h-100 border-0 shadow-sm">
          <div className="card-body">
            <img src={p5} className="mb-3" alt="Category Icon" />
            
          </div>
        </div>
      </div>

	  <div className="col">
        <div className="card text-center h-100 border-0 shadow-sm">
          <div className="card-body">
            <img src={p6} className="mb-3" alt="Category Icon" />
            
          </div>
        </div>
      </div>
	  <div className="col">
        <div className="card text-center h-100 border-0 shadow-sm">
          <div className="card-body">
            <img src={p7} className="mb-3" alt="Category Icon" />
            
          </div>
        </div>
      </div>
	  <div className="col">
        <div className="card text-center h-100 border-0 shadow-sm">
          <div className="card-body">
            <img src={p8} className="mb-3" alt="Category Icon" />
            
          </div>
        </div>
      </div>


	

    

    </div>
  </div>

    </div>
  )
}

export default Card
