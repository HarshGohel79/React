import React from "react";
import Card from "./Card";
import Slider from "./Slider";
import { Link } from "react-router-dom";







function Hedars() {

  
  
  return (
    <div>
<Link to={'/'}></Link>
      <Slider />
      <Card />
 
 
    </div>
  );
}

export default Hedars;
