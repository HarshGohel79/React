import React from 'react'
import "react-toastify/dist/ReactToastify.css";
import { toast, ToastContainer } from 'react-toastify';

function Tosity() {
  const notify = () => toast("Wow so easy!");
  return (
    <div>
    <button onClick={notify}>Notify!</button>
    <ToastContainer />
    </div>
  )
}

export default Tosity
