import React from 'react'
import Mensbag from '../Leyout/MenBag'

function Men() {
  return (
    <div>
      <Mensbag/>
    </div>
  )
}

export default Men
