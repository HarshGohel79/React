import React from 'react'

function HomeProduct() {
  return (
    <div>HomeProduct</div>
  )
}

export default HomeProduct