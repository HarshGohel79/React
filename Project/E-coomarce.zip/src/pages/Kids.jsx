import React from 'react'

function Kids() {
  return (
    <div>
      
    </div>
  )
}

export default Kids
