import React from 'react'

function Beauty() {
  return (
    <div>
      
    </div>
  )
}

export default Beauty
