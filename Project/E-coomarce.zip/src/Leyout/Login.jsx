import React, { useContext, useState } from "react";
import "../assets/styles/Login.css";
import { Link, useNavigate } from "react-router-dom";
import { UserLogin } from "../App";
import { toast, ToastContainer } from "react-toastify";


function Login() {
  const { loginame, useloginame, loginLogout, setLogin } =  useContext(UserLogin);

  const [leemail, setemail] = useState("");
  const [lepassword, setpassword] = useState('');
  const nav = useNavigate();


  const canlogin = leemail!="" && lepassword!="" ;

 
  const handalsubmit = (e) => {
    e.preventDefault();
    // loginame(setemail);
    nav("/");

  };
  

  const Notify = () =>{
    toast("Welcome ")
    
  }
 

 
  return (
    <div>
      <h1 className="x1">Login</h1>
      <form className="x" onSubmit={handalsubmit}>
        <div className="mb-3 ">
          <label for="exampleInputEmail1" className="form-label">
            Email address
          </label>
          <input
            type="email"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            value={leemail}
            onChange={(e) => {
              setemail(e.target.value);
            }}
          />
        </div>
        <div className="mb-3">
          <label for="exampleInputPassword1" className="form-label">
            Password
          </label>
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            value={lepassword}
            onChange={(e) => {
              setpassword(e.target.value);
            }}
          />
        </div>
        <div className="mb-3 form-check">
          <input
            type="checkbox"
            className="form-check-input"
            id="exampleCheck1"
          />
          <label className="form-check-label" for="exampleCheck1">
            Check me out
          </label>
        </div>
      
          
          <button type="submit" className="btn btn-primary" disabled={!canlogin} onClick={Notify} >
            Submit
          </button>

          <ToastContainer/>
          
      </form>
    </div>
  );
}

export default Login;
