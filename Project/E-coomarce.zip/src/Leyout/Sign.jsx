import React, { useState } from 'react'
import { Link } from 'react-router-dom'

export default function Sign() {

 const [nameLogin ,setnamelogin] = useState('')
 const [nameemail ,setnameemail] = useState('')
  return (
    <div>
       <div className="container mt-5">
    <div className="row justify-content-center">
      <div className="col-md-6">
        <div className="card shadow">
          <div className="card-header text-center">
            <h4>Register</h4>
          </div>
          <div className="card-body">
            <form>
              <div className="mb-3">
                <label for="fullName" className="form-label" >Full Name</label>
                <input type="text" className="form-control" id="fullName" required value={nameLogin} onChange={(e)=>{
                  setnamelogin(e.target.value)
                }}/>
              </div>
              <div className="mb-3">
                <label for="email" className="form-label">Email address</label>
                <input type="email" className="form-control" id="email" required value={nameemail} onChange={(e)=>{
                  setnameemail(e.target.value)
                }}/>
              </div>
              <div className="mb-3">
                <label for="address" className="form-label">Address</label>
                <textarea className="form-control" id="address" rows="2" required></textarea>
              </div>
              <div className="mb-3">
                <label for="pincode" className="form-label">Pincode</label>
                <input type="text" className="form-control" id="pincode" required pattern="\d{6}" title="Enter 6-digit pincode"/>
              </div>
              <div className="mb-3">
                <label for="password" className="form-label">Password</label>
                <input type="password" className="form-control" id="password" required/>
              </div>
              <div className="mb-3">
                <label for="confirmPassword" className="form-label">Confirm Password</label>
                <input type="password" className="form-control" id="confirmPassword" required/>
              </div>
             <Link to={'/'}>
             <button type="submit" className="btn btn-primary w-100">Register</button></Link>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
    </div>
  )
}
