import React, { useEffect, useState } from 'react'
import "../assets/styles/productGrid.css";
const Womens = () => {

  const [wom,setwom] = useState([]);

  useEffect(()=>{
    fetch("http://localhost:3003/products")
    .then((res)=>res.json())
    .then((data)=>{
      setwom(data)
    },[])
  })
  return (
    <div>

<div className="container my-5 py-3">
        <h1 className="pb-2">Women's Bags</h1>
        <div className="productGrid">
          {wom.map((product, index) => (
            <div className="product shadow" key={index}>
              <div className="img_box">
                <img src={product.image_url} alt={product.name} />
              </div>
              <div className="txt_box">
                <h5>{product.name}</h5>
                <p>MRP : ₹ {product.price}</p>
              </div>
              <button>Add to cart</button>
              {/* <ButtonChilderen Children="Add to cart"></ButtonChilderen> */}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Womens