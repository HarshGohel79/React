import React, { useEffect, useState } from "react";
import "../assets/styles/productGrid.css";
// import ButtonChilderen from "./ButtonChilderen";

const Mensbag = () => {
  const [bags, setbags] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3002/products")
      .then((res) => res.json())
      .then((data) => {
        // const mensBags = data.filter(
        //   (product) => product.category === "mens_bags"
        // );
        // setbags(mensBags);

        setbags(data)
      });
  }, []);
  return (
    <>

    
      <div className="container my-5 py-3">
        <h1 className="pb-2">Men's Bags</h1>
        <div className="productGrid">
          {bags.map((product, index) => (
            <div className="product shadow" key={index}>
              <div className="img_box">
                <img src={product.image} alt={product.name} />
              </div>
              <div className="txt_box">
                <h5>{product.name}</h5>
                <p>MRP : ₹ {product.price}</p>
              </div>
              <button>Add to Cart</button>
              {/* <ButtonChilderen Children="Add to cart"></ButtonChilderen> */}
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Mensbag;
