import { BrowserRouter, Route, Routes } from "react-router-dom";
import Footer from "./Componets/Footer";
import Hedars from "./Componets/Hedars";
import { createContext, useState } from "react";
import Login from "./Leyout/Login";
import Sign from "./Leyout/Sign";
import Men from "./Leyout/MenBag";
import Navbarr from "./Componets/Navbar";
import Womens from "./Leyout/Womens";
import Kids from "./Leyout/Kids";
import Beauty from "./Leyout/Beauty";
import Tosity from "./Componets/Tosity";


export const UserLogin = createContext()

function App() {
const [loginame, useloginame] = useState('')
const [loginLogout, setLogin] = useState(true)




console.log(loginame)
  return (
    <div className="App">
      <BrowserRouter>
        <UserLogin.Provider value={{ loginame, useloginame  ,loginLogout, setLogin }}>
          <Navbarr/>
          {loginame}
          <Routes>
            <Route path="/" element={<Hedars />}></Route>
            <Route path="/Men" element={<Men/>}></Route>
             <Route path="/Womens" element={< Womens/>}></Route>
            <Route path="/kids" element={< Kids/>}></Route>
            <Route path="/Beauty" element={< Beauty/>}></Route>
            <Route path="/login" element={<Login />}></Route>
            <Route path="/Sign" element={<Sign/>}></Route>
           
          </Routes>
               <Footer />
             
        </UserLogin.Provider>
      </BrowserRouter>

    </div>
  );
}

export default App;
